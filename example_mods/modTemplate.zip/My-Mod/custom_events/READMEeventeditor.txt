================================================================================
EVENT CREATOR — SUPER PLUS ENGINE (BETA FEATURE)
================================================================================

Super Plus has a built-in visual editor for creating custom Lua events,
without writing code. Events appear in the Chart Editor dropdown and can
be triggered like any native event.


--------------------------------------------------------------------------------
1. OPEN THE EDITOR
--------------------------------------------------------------------------------

  Chart Editor → File → Custom Events...

You can also open an existing event from there


--------------------------------------------------------------------------------
2. WHAT IT GENERATES
--------------------------------------------------------------------------------

The editor creates TWO files per event (name = the one you write in the
"Name" field):

  mods/<your_mod>/custom_events/<Name>.lua   → the event code (run by PlayState)
  mods/<your_mod>/custom_events/<Name>.txt   → description shown in the Chart Editor

Without an active mod, files go to mods/custom_events/ (global folder).

The name keeps uppercase and spaces ("Glitch Effect" → "Glitch Effect.lua").
Only invalid filename characters are replaced with underscore.


--------------------------------------------------------------------------------
3. THE FOUR TABS
--------------------------------------------------------------------------------

  Metadata    → event name, category, description, how many values are in the chart
  Parameters  → what the event asks the charter for (inputs)
  Actions     → the blocks that run when the event fires
  Code        → live preview of the generated Lua (read-only)


--------------------------------------------------------------------------------
4. METADATA
--------------------------------------------------------------------------------

  Name          → event ID (used for the file name and the Chart Editor dropdown)
  Category      → Visual / Audio / Camera / Gameplay / Other (only groups events)
  Description   → shown in the Chart Editor when the event is selected
  Values exposed in chart (0-2) → how many parameters the charter can edit

The chart format only supports value1 and value2, so max 2 parameters can
be exposed. Any extra parameter becomes a fixed constant written in the Lua.


--------------------------------------------------------------------------------
5. PARAMETERS
--------------------------------------------------------------------------------

A parameter is an input the charter fills in the chart.

  Name      → variable name used by the code (e.g. "target", "intensity")
  Type      → text, int, float, bool, slider, dropdown, character, color,
              sound, image, stage
  Default   → used when the charter leaves the field empty
  Min / Max / Step → only for slider, int, float (when range is enabled)
  Options   → only for dropdown (comma-separated list)

The first 2 non-fixed parameters become value1 and value2 in the chart.
Fixed ones, and any beyond the first two, are constants written in the Lua.

Click the "[V1] / [V2]" badge on a row to toggle between "exposed in chart"
and "fixed constant".


--------------------------------------------------------------------------------
6. ACTIONS
--------------------------------------------------------------------------------

Actions are built from blocks. Click "+ Add block..." to open the palette.

Palette categories:

  Visual   → tween alpha / angle / X / Y / position / scale / color,
             set property, set visible, play animation, add/remove sprite
  Audio    → play sound, play sound (tagged), play music, stop sound,
             set volume, fade sound
  Camera   → shake, flash, fade, zoom, target
  Gameplay → change character, change stage, add health, set health,
             add score, add misses, trigger event
  Other    → wait, debug print, custom Lua

Each block has its own fields. Fields can be:

  - a literal value ("boyfriend", "0.5", "360", ...)
  - a reference to a parameter (click the "$" button, then pick a parameter)

Blocks run top to bottom. Use "Delete", "Up", "Down", "Dup" to manage them.


--------------------------------------------------------------------------------
7. THE WAIT BLOCK
--------------------------------------------------------------------------------

Wait pauses the event. Everything AFTER it runs later (via runTimer +
onTimerCompleted). You can chain multiple Waits; each one nests the blocks
after it in a closure.

Example flow:
  Play Sound → Wait 1s → Tween Alpha → Wait 0.5s → Tween Alpha


--------------------------------------------------------------------------------
8. SAVING AND REOPENING
--------------------------------------------------------------------------------

  Save to custom_events/   → writes <Name>.lua + <Name>.txt

  Open existing...         → opens a .lua from custom_events/
                             If it was generated by the editor, the
                             Metadata/Parameters/Actions tabs are rebuilt
                             from the round-trip header.
                             If it was modified by hand, it opens as
                             manual code (Code tab) so nothing is lost.
                             Files without the header open as manual code.

  Regenerate (Code tab)    → discard the manual code and go back to
                             generating from Parameters/Actions.


--------------------------------------------------------------------------------
9. USING THE EVENT IN A CHART
--------------------------------------------------------------------------------

  1. Save the event to custom_events/ (the editor does this).
  2. Open the Chart Editor → Events tab.
  3. The event appears in the dropdown (with its description).
  4. Place it on the chart.
  5. Fill value1 and value2 if the event exposes parameters.
  6. Playtest. The event fires at the right time.


--------------------------------------------------------------------------------
10. THE PALETTE (blocks.json)
--------------------------------------------------------------------------------

The palette is loaded from:

  assets/shared/data/eventCreator/blocks.json
  mods/<your_mod>/data/eventCreator/blocks.json  (extends / overrides)

Mods can add their own blocks without recompiling. Each block has:
  id, name, category, desc, fields[], template

Fields:
  { "key": "target", "label": "Target", "type": "object", "def": "boyfriend" }

Template uses $placeholders:
  "doTweenAngle($tag, $target, $value, $duration, $ease)"

$tag is auto-generated. $lua:<expression> is an escape hatch for raw Lua.


--------------------------------------------------------------------------------
11. IMPORTANT RULES
--------------------------------------------------------------------------------

  - Event IDs cannot collide with native events (Hey!, Change Stage,
    Change Character, etc.). The editor blocks the save.

  - Max 20 blocks per event. Max 12 parameters.

  - Parameter names must be valid Lua identifiers after sanitization.
    Reserved names (eventName, value1, value2, strumTime, ec_*, etc.)
    are renamed with a trailing underscore.

  - The generated Lua calls onEvent globally with a guard on the event
    name. PlayState calls onEvent for every event on the chart, so the
    guard is required.

  - Don't trigger the same event from a "Trigger Event" block: it would
    loop forever. The editor blocks that too.


--------------------------------------------------------------------------------
12. KNOWN ISSUES
--------------------------------------------------------------------------------

  - Dropdowns in the editor may visually overflow when opened. Cosmetic
    only: selection and codegen work correctly. Planned fix for 1.3.


--------------------------------------------------------------------------------
13. LIMITATIONS (current)
--------------------------------------------------------------------------------

  - Only 2 chart values (value1 / value2) can be exposed per event.
  - Custom Lua blocks are single-line only.
  - Undo/Redo not implemented.
  - Dry-run (test without saving) not implemented.
