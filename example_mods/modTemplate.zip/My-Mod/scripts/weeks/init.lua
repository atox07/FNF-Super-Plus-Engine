function onLoadWeeks(isStoryMode)
    hideBaseWeeks()
end