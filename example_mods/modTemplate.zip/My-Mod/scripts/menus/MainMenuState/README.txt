================================================================================
MENU SCRIPTING — SUPER PLUS ENGINE (BETA FEATURE)
================================================================================

Super Plus lets you customize menus (currently the Main Menu) using Lua or
HScript scripts, without touching the source code. Same idea as PlayState
modding, but applied to menus.


--------------------------------------------------------------------------------
1. WHERE TO PUT SCRIPTS
--------------------------------------------------------------------------------

  mods/<your_mod>/scripts/menus/MainMenuState/init.lua

You can also use "init.hx" (HScript) — both are loaded if present.
Scripts are searched in: active mod → global mods → assets/shared.


--------------------------------------------------------------------------------
2. SCRIPT STRUCTURE
--------------------------------------------------------------------------------

A minimal script:

  function onCreatePost()
      -- menu is built, you can add stuff here
  end

  function onUpdate(elapsed)
      -- every frame
  end

  function onDestroy()
      -- menu is closing
  end


--------------------------------------------------------------------------------
3. AVAILABLE CALLBACKS
--------------------------------------------------------------------------------

  onCreate      → script loaded, before the menu is built
  onCreatePost  → menu fully built (this is where you add things)
  onUpdate      → every frame (elapsed = delta time in seconds)
  onDestroy     → menu is closing (cleanup)


--------------------------------------------------------------------------------
4. MENU FUNCTIONS
--------------------------------------------------------------------------------

Title and look:

  setMenuTitle(text)
  setMenuColor(r, g, b)          -- 0.0 to 1.0 each
  setMenuBackground(imagePath)

Buttons:

  addMenuButton(text, callback)  -- add a button with a callback
  removeMenuButton(text)         -- remove a button by its text
  clearMenuButtons()             -- remove all custom buttons

Hide the default menu:

  hideDefaultMenu(true)          -- hide Story Mode / Freeplay / Mods / Credits
  hideDefaultMenu(false)         -- show them again


--------------------------------------------------------------------------------
5. ACTIONS (open other states)
--------------------------------------------------------------------------------

  openFreeplay()
  openOptions()
  openStoryMode()
  openMods()
  quitGame()
  startSong(songName)


--------------------------------------------------------------------------------
6. VISUAL FUNCTIONS (same names as PlayState modding)
--------------------------------------------------------------------------------

Sprites:

  makeLuaSprite(tag, imagePath, x, y)
  makeAnimatedLuaSprite(tag, imagePath, x, y)
  addLuaSprite(tag, true)              -- ALWAYS use true in menus (see §9)
  removeLuaSprite(tag, destroy)

Text:

  makeLuaText(tag, text, width, x, y)
  addLuaText(tag)
  setTextString(tag, text)
  setTextSize(tag, size)
  setTextColor(tag, hexColor)

Properties:

  getProperty("tag.property")
  setProperty("tag.property", value)

Animations:

  addAnimationByPrefix(tag, name, prefix, framerate, loop)
  playAnim(tag, animName, force)

Tweens:

  doTweenX(tag, variable, value, duration, ease)
  doTweenY(tag, variable, value, duration, ease)
  doTweenAlpha(tag, variable, value, duration, ease)
  doTweenAngle(tag, variable, value, duration, ease)
  doTweenColor(tag, variable, color, duration, ease)
  cancelTween(tag)

Audio:

  playSound(path, volume)
  playMusic(path, volume, loop)


--------------------------------------------------------------------------------
7. BUILDING A CLICKABLE BUTTON
--------------------------------------------------------------------------------

setSpriteCallback is NOT available. Use onUpdate + mouse check:

  function onCreatePost()
      hideDefaultMenu(true)
      makeLuaSprite("playBtn", "mainmenu/menu_freeplay", 200, 300)
      addLuaSprite("playBtn", true)
  end

  function onUpdate(elapsed)
      if mouseOverlaps("playBtn") and mouseClicked() then
          openFreeplay()
      end
  end

Notes:
  - mouseOverlaps and mouseClicked work in menus.
  - For hover effects, compare the state with a local variable to avoid
    re-firing tweens every frame.


--------------------------------------------------------------------------------
8. EXAMPLE — SIMPLE CUSTOM MENU
--------------------------------------------------------------------------------

  function onCreatePost()
      hideDefaultMenu(true)

      setMenuTitle("MY MOD MENU")
      setMenuColor(1, 0, 1)

      makeLuaText("title", "MY MOD MENU", 0, 100, 50)
      setTextSize("title", 64)
      addLuaText("title")

      makeLuaSprite("playBtn", "mainmenu/menu_freeplay", 0, 200)
      setProperty("playBtn.x", (screenWidth / 2) - (getProperty("playBtn.width") / 2))
      addLuaSprite("playBtn", true)

      makeLuaSprite("optBtn", "mainmenu/menu_story_mode", 0, 350)
      setProperty("optBtn.x", (screenWidth / 2) - (getProperty("optBtn.width") / 2))
      addLuaSprite("optBtn", true)
  end

  function onUpdate(elapsed)
      if mouseClicked() then
          if mouseOverlaps("playBtn") then
              openFreeplay()
          elseif mouseOverlaps("optBtn") then
              openOptions()
          end
      end
  end


--------------------------------------------------------------------------------
9. IMPORTANT RULES
--------------------------------------------------------------------------------

  - addLuaSprite(tag, false) WILL CRASH in menus. Always use true.

  - screenCenter does not work in menus. Center manually:
        setProperty("tag.x", (screenWidth - getProperty("tag.width")) / 2)

  - hideDefaultMenu(true) blocks keyboard and mouse input for the default
    buttons. Your custom onUpdate still runs, so handle your own input.

  - Avoid non-ASCII characters (emoji, accented letters) inside string
    literals in Lua. The parser does not handle them well.

  - Changing text/value/checked from code does NOT fire callbacks
    (no infinite loops).

  - visible = false does not hide from clicks. Use exists = false if you
    need to fully disable a widget.

  - Scripts run once per menu open. To reload, close and reopen the menu.


--------------------------------------------------------------------------------
10. DEBUGGING
--------------------------------------------------------------------------------

  Use debugPrint("message", "WHITE") to log to the game's debug overlay.
  In menus the overlay may not be visible: check the terminal or log file.

  For quick checks, use visible effects instead:
      makeLuaText("dbg", "test", 0, 10, 10)
      addLuaText("dbg")


--------------------------------------------------------------------------------
11. LIMITATIONS (current)
--------------------------------------------------------------------------------

  - Only MainMenuState is scriptable for now.
  - setSpriteCallback is not implemented: use onUpdate + mouse check.
  - screenCenter does not work in menus.
  - No SoundTest API yet.
  - Custom menus beyond the Main Menu need CustomScriptState (planned).

